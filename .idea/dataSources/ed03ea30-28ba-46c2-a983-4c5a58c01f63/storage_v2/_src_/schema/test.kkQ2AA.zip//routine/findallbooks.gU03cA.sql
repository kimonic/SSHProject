create procedure findAllBooks()
  BEGIN
   select * from books order by id desc;

END;

