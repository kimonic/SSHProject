create procedure findAllBoo()
  BEGIN
   select * from books;

END;

